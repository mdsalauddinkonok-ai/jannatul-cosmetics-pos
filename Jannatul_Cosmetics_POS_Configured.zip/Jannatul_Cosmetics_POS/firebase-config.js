// Firebase Console থেকে আপনার Jannatul Cosmetics POS Web App-এর Config
export const firebaseConfig = {
  apiKey: "AIzaSyD1zMqRO6lpkoQ0EB69wCSmDVUqOF3PPDs",
  authDomain: "jannatul-cosmetics-pos.firebaseapp.com",
  projectId: "jannatul-cosmetics-pos",
  storageBucket: "jannatul-cosmetics-pos.firebasestorage.app",
  messagingSenderId: "310608163834",
  appId: "1:310608163834:web:c5177d559b7a94263faa43",
  measurementId: "G-GEJQKLC60F"
};
