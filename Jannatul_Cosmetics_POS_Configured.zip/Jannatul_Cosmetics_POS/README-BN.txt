JANNATUL COSMETICS & COMPUTER — PREMIUM HTML POS
=================================================

এই প্যাকেজে আছে:
- index.html, style.css, app.js
- Firebase config template
- Firestore security rules
- PWA manifest

গুরুত্বপূর্ণ সীমাবদ্ধতা:
এটি একটি কার্যকর প্রাথমিক POS সংস্করণ। Firebase Spark ফ্রি প্ল্যানের সীমা প্রযোজ্য।
অফলাইন Firestore cache ও offline writes চালু করার চেষ্টা করা হয়; তবে প্রথম লগইন,
প্রাথমিক ডেটা লোড এবং নতুন ডিভাইসে ডেটা সিঙ্কের জন্য ইন্টারনেট প্রয়োজন।
একই দোকানের দুই ডিভাইসে আপাতত একই Firebase Authentication অ্যাকাউন্ট দিয়ে লগইন করুন।
একাধিক আলাদা কর্মচারী অ্যাকাউন্ট/পারমিশন, ছবি Cloud Storage, supplier ledger,
পূর্ণাঙ্গ return/exchange, salary, barcode camera এবং advanced audit পরবর্তী সংস্করণে
যোগ করা প্রয়োজন। অফলাইনে একই পণ্য একাধিক ডিভাইস থেকে একসঙ্গে বিক্রি করলে স্টক
সংঘর্ষ হতে পারে; অনলাইন অবস্থায় বিক্রি করা সবচেয়ে নিরাপদ।

A. Firebase বিনামূল্যে সেটআপ
----------------------------
1. https://console.firebase.google.com খুলে Google account দিয়ে লগইন করুন।
2. Add project > Project name: jannatul-cosmetics-pos দিন।
3. Google Analytics বন্ধ রাখতে পারেন; Create project করুন।
4. Project Overview > Web (</>) আইকন চাপুন।
5. App nickname: Jannatul POS দিয়ে Register app করুন।
6. Firebase যে config দেখাবে তা কপি করুন।
7. এই ফোল্ডারের firebase-config.js খুলে apiKey, authDomain, projectId,
   storageBucket, messagingSenderId, appId-এর জায়গায় নিজের config বসান।
8. Firebase Console > Authentication > Get started > Sign-in method >
   Email/Password Enable করুন।
9. Authentication > Users > Add user দিয়ে নিজের ইমেইল ও পাসওয়ার্ড তৈরি করুন।
10. Firestore Database > Create database > Production mode নির্বাচন করুন।
11. Firestore > Rules-এ firestore.rules ফাইলের সম্পূর্ণ নিয়ম paste করে Publish করুন।

B. কম্পিউটারে চালানো
--------------------
ES module ও Firebase CDN ব্যবহারের কারণে index.html-এ ডাবল ক্লিক করে (file://)
চালাবেন না। ফোল্ডারটি একটি static hosting-এ publish করুন অথবা local server চালান।
সহজ উপায়: VS Code-এ ফোল্ডার খুলে Live Server extension দিয়ে Open with Live Server।

C. দুই ডিভাইসে চালানো — GitHub Pages
------------------------------------
1. https://github.com এ ফ্রি অ্যাকাউন্ট খুলুন।
2. New repository তৈরি করুন; নাম jannatul-cosmetics-pos দিন।
3. এই ফোল্ডারের সব ফাইল repository-তে upload করুন।
4. Repository > Settings > Pages > Deploy from a branch নির্বাচন করুন।
5. Branch: main এবং folder: /(root) নির্বাচন করে Save করুন।
6. কিছুক্ষণ পরে GitHub Pages URL তৈরি হবে।
7. সেই URL দুই ডিভাইসে খুলে একই Firebase email/password দিয়ে লগইন করুন।
8. Chrome menu > Install app / Add to Home Screen ব্যবহার করতে পারেন।

D. ব্যবহার শুরু
---------------
1. Products > নতুন পণ্য যোগ করে পণ্য, ক্রয়মূল্য, বিক্রয়মূল্য ও স্টক দিন।
2. Sales > পণ্য যোগ করে কাস্টমার, ডিসকাউন্ট, জমা দিয়ে বিক্রয় সম্পন্ন করুন।
3. বিক্রয় সফল হলে মেমো প্রিন্ট ডায়ালগ আসবে।
4. Purchases থেকে ক্রয় করলে স্টক বাড়বে।
5. Expenses থেকে আয় বা ব্যয় নথিভুক্ত করুন।
6. Customers থেকে কাস্টমার যোগ এবং বাকি আদায়ের রেকর্ড দেখুন।
7. Backup থেকে নিয়মিত JSON ব্যাকআপ ডাউনলোড করুন।

E. নিরাপত্তা ও ডেটা
------------------
- firebase-config.js-এ Firebase web config গোপন পাসওয়ার্ড নয়; নিরাপত্তা Firestore Rules দিয়ে হয়।
- Firebase Admin SDK/private key কখনো HTML/JS ফাইলে রাখবেন না।
- Firestore rules কেবল authenticated UID-কে তার UID path-এ প্রবেশ করতে দেয়।
- একই UID-তে ডেটা থাকায় দুই ডিভাইসে একই login ব্যবহার করুন।
- দোকানের ডেটা ব্যবহারের আগে পরীক্ষা করার জন্য কয়েকটি dummy পণ্য দিয়ে trial করুন।
- নিয়মিত JSON backup রাখুন এবং অন্য ডিভাইসে backup restore পরীক্ষা করুন।
- Firebase Spark প্ল্যানে usage quota আছে; quota/নীতিমালা বদলাতে পারে। Console-এ usage দেখুন।

এই starter সংস্করণে হিসাবের নির্ভুলতা নিশ্চিত করতে সব বিক্রির আগে স্টক যাচাই করা হয়,
কিন্তু offline concurrent sale-এ সম্পূর্ণ server-side stock reservation নেই।
বড় পরিসরে ব্যবহারের আগে transaction/server-side validation যুক্ত করা উচিত।
